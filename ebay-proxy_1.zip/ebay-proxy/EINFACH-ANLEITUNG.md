# Server einrichten — ganz einfach

Du brauchst dafür **kein Programmieren** und **kein Terminal**. Nur zwei
kostenlose Webseiten und ein bisschen Klicken. Dauert ca. 10 Minuten.

Du brauchst vorher: deine **App ID** und **Cert ID** von eBay (hast du schon
bei developer.ebay.com angelegt).

---

## Teil 1: Die Dateien bei GitHub ablegen

GitHub ist einfach nur ein kostenloser Online-Speicher für Projekt-Dateien.

**1.1** Geh auf **github.com** und klick oben rechts auf **Sign up**.
Registrier dich kostenlos (E-Mail + Passwort reicht).

**1.2** Nach dem Einloggen: Klick oben rechts auf das **+**-Symbol, dann auf
**New repository**.

**1.3** Gib bei "Repository name" einen Namen ein, z. B. `ebay-server`.
Lass alles andere wie es ist und klick unten auf **Create repository**.

**1.4** Du siehst jetzt eine fast leere Projektseite. Klick auf
**Add file** → **Upload files**.

**1.5** Entpack jetzt auf deinem Computer die ZIP-Datei, die ich dir gegeben
habe (Rechtsklick → "Extrahieren" o. ä.). Du hast dann einen Ordner
`ebay-proxy` mit einem Unterordner `api` drin.

**1.6** Zieh **den ganzen Inhalt** dieses Ordners (den Unterordner `api` und
die Datei `package.json`) mit der Maus in das Upload-Feld im Browser.
Wichtig: nicht einzelne Dateien rauskopieren, sondern alles zusammen
reinziehen, damit die Ordnerstruktur erhalten bleibt.

**1.7** Scroll runter, klick auf **Commit changes**.

Fertig — deine Dateien liegen jetzt bei GitHub.

---

## Teil 2: Bei Vercel veröffentlichen

Vercel ist der Dienst, der aus deinen Dateien einen echten, erreichbaren
Server macht — kostenlos für diese Zwecke.

**2.1** Geh auf **vercel.com** und klick auf **Sign Up**.

**2.2** Wähl **Continue with GitHub** — so nutzt du direkt dein gerade
erstelltes Konto, kein neues Passwort nötig.

**2.3** Im Vercel-Dashboard: Klick auf **Add New** → **Project**.

**2.4** Du siehst eine Liste deiner GitHub-Projekte. Suche `ebay-server`
(oder wie du es genannt hast) und klick daneben auf **Import**.

**2.5** Jetzt kommt der wichtigste Schritt — **noch nicht auf Deploy
klicken!** Klapp auf dieser Seite den Bereich **Environment Variables** auf.
Trag genau zwei Einträge ein:

| Name | Wert |
|---|---|
| `EBAY_CLIENT_ID` | deine App ID |
| `EBAY_CLIENT_SECRET` | deine Cert ID |

Für jeden Eintrag: Namen eingeben, Wert eingeben, auf **Add** klicken.

**2.6** Erst jetzt auf den großen **Deploy**-Button klicken.

**2.7** Warte ca. 1 Minute. Danach zeigt dir Vercel eine fertige Adresse,
z. B. `https://ebay-server-deinname.vercel.app`. **Diese Adresse kopieren.**

---

## Teil 3: Im Reseller Center eintragen

Öffne dein Reseller Center → **Einstellungen** → Bereich
**"eBay-Datenabgleich"** → die kopierte Adresse einfügen → speichern.

Fertig! Der Knopf "Von eBay übernehmen" im Produktformular funktioniert jetzt.

---

## Wenn irgendwas nicht klappt

Mach einen Screenshot von der Stelle, an der es hakt, und schick ihn mir —
dann schauen wir zusammen, woran's liegt.
